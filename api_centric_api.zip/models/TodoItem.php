<?php
class TodoItem
{
    public $todo_id;
    public $title;
    public $description;
    public $due_date;
    public $is_done;
     
    public function save($username, $userpass)
    {
        //get the username/password hash
        $userhash = sha1("{$username}_{$userpass}");

        if( is_dir(DATA_PATH."/{$userhash}") === false ) {

            mkdir(DATA_PATH."/{$userhash}");
        }
         
        //if the $todo_id isn't set yet, it means we need to create a new todo item
        if( is_null($this->todo_id) || !is_numeric($this->todo_id) ) {
            //the todo id is the current time
            $this->todo_id = time();
        }
         
        //get the array version of this todo item
        $todo_item_array = $this->toArray();
         
        //save the serialized array version into a file
        $success = file_put_contents(DATA_PATH."/{$userhash}/{$this->todo_id}.txt", serialize($todo_item_array));
         
        //if saving was not successful, throw an exception
        if( $success === false ) {
            throw new Exception('Failed to save todo item');
        }
         
        //return the array version
        return $todo_item_array;
    }
     
    public function toArray()
    {
        //return an array version of the todo item
        return array(
            'todo_id' => $this->todo_id,
            'title' => $this->title,
            'description' => $this->description,
            'due_date' => $this->due_date,
            'is_done' => $this->is_done
        );


    }

    public function readData($username, $userpass)
    {
        // return array(
        //     'todo_id' => 'A',
        //     'title' => 'B',
        //     'description' => 'C',
        //     'due_date' => 'D',
        //     'is_done' => 'E'
        // );
        $userhash = sha1("{$username}_{$userpass}");
        $dir = DATA_PATH."/".$userhash;
        $files = scandir($dir, 1);

        $files_content_arr = array();

        for ($i=0; $i < count($files)-2; $i++) { 
            $content = file_get_contents(DATA_PATH."/{$userhash}/".$files[$i]);
            $files_content_arr[] = unserialize($content);
        }
               
        return $files_content_arr;
         
    }

    public function updateData($username, $userpass)
    {
        $userhash = sha1("{$username}_{$userpass}");

        //get the array version of this todo item
        $todo_item_array = $this->toArray();

        //return $arrayName = array('todo_id' => $this->todo_id );
         
        //save the serialized array version into a file
        $success = file_put_contents(DATA_PATH."/{$userhash}/{$this->todo_id}.txt", serialize($todo_item_array));
         
         if( $success === false ) {
            throw new Exception('Unable to update todo item');
        }
         
        //return the array version
        return $todo_item_array;
    }
}