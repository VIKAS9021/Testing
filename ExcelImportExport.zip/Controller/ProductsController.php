<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Core\Configure;
use Cake\Validation\Validator;
use Cake\Cache\Cache;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 */
class ProductsController extends AppController
{

    /**
     * Index method
     *
     * @return void
     */

    public $helpers = ['Common','ImageResize'];

    public function initialize()
    {
         parent::initialize();
         $this->loadComponent('Paypal');  
         $this->loadComponent('ExcelExport');  

         // Using a short name
        Cache::config('short', [
            'className' => 'File',
            'duration' => '+1 minutes',
            'path' => CACHE,
            'prefix' => 'cake_short_'
        ]);

        
    }

    public function mysearch()
    {
        $this->loadComponent('Search.Prg');

        $query = $this->Products
                ->find('search', $this->request->query)
                ->contain([
                'ProductImages','ProductsCategories'
                ]);

//pr($query->toArray())
        $baseurl = Configure::read('base_url');
        $this->set('baseurl',$baseurl); 
        $pcat = $this->Products->ProductsCategories->find();
        //pr($pcat->toArray());
        $this->set('pcategories', $pcat->toArray());
        
        $this->set('products', $this->paginate($query));
        $this->set('_serialize', ['products']);

         /* ->order(['Country.id' => 'asc'])
         ->contain([
                'Cities'
            ]); */
        $this->render('index');
        
    }

    public function index()
    {
        $this->paginate = [
                'contain' => ['ProductImages','ProductsCategories'],
                'limit'   => 9,
                ]; 

        $baseurl = Configure::read('base_url');
        $this->set('baseurl',$baseurl); 
        $pcat = $this->Products->ProductsCategories->find();
        //pr($pcat->toArray());
        $this->set('pcategories', $pcat->toArray());       
        $this->set('products', $this->paginate($this->Products));
        $this->set('_serialize', ['products']);

        
    }

    public function loadMore()
    {
        $page = $this->request->data['page'];
        //$page = 3;
        /*
        // one way 
        $queryObj = $this->Products->customPaginate($page,3);
        //debug($queryObj);
        pr($queryObj->fetchAll('assoc'));
        echo json_encode($queryObj->fetchAll('assoc'));*/

        //one way two
        //$offset = ($page - 1) * $limit = $row_start
         //$page = ;
        //$limit = ;
        $queryObj = $this->Products->customPaginate($page,3);
        //debug($queryObj);
      //  pr(json_encode($queryObj->toArray()));
       echo json_encode($queryObj->toArray());
        exit();
    }

    public function search()
    {
        
        $cat_id = $this->request->query['cat_id'];

        $product_price = $this->request->query['product_price'];
        
        //$cat_id = 2;
        $queryObj = $this->Products->customSearch($cat_id,$product_price);
        //debug($queryObj);
        //pr($queryObj->toArray());
        echo json_encode($queryObj->toArray());
        exit();
    }

    public function searchbypricerange()
    {
        $pricerange = $this->request->data['pricerange'];
        $values = str_replace(' ','',$pricerange);
        $values = explode('-',$values);
        $min = $values[0];
        $max = $values[1];

        $queryObj = $this->Products->searchByPriceRange($min,$max);
        echo json_encode($queryObj->toArray());
        exit();
    }

    public function addtocart()
    {
        
        $session = $this->request->session();

        $cart = $session->read('cart');
        $price = $this->request->data['price'];
        $pid = $this->request->data['pid'];
        $pname = $this->request->data['pname'];

        $cart['items'][$pid] = [
                'pname' => $pname,
                'qty' => (!empty($cart['items'][$pid]['qty']))?$cart['items'][$pid]['qty']+1 : 1,
                'price' => $price
        ] ;
        $session->write('cart', $cart);
        echo count($session->read('cart.items'));
        exit;
        //pr($session->read('cart'));
        //$session->delete('cart');
        //exit;
    }

    public function getcartitems()
    {
        $session = $this->request->session();
        echo json_encode($session->read('cart.items'));
        exit;
    }

    public function checkout()
    {
        $session = $this->request->session();
        $cartitems = $session->read('cart.items');

        $baseurl = Configure::read('base_url');
        $this->set('baseurl',$baseurl);
        $this->set('items', $cartitems);
    }



    public function updatecart()
    {
        $session = $this->request->session();
        $cart = $session->read('cart');
        $pid = $this->request->data['pid'];
        $qty = $this->request->data['qty'];

        $cart['items'][$pid]['qty'] = $qty;
        $session->write('cart', $cart); 
        exit;
    }

    public function removeItem()
    {
      $session = $this->request->session();
      $cart = $session->read('cart');
      $pid = $this->request->data['pid'];
      $session->delete("cart.items.$pid");
      exit;  
    }

    public function buyproducts()
    {
        $requestParams = array(
        'IPADDRESS' => $_SERVER['REMOTE_ADDR'],          // Get our IP Address
        'PAYMENTACTION' => 'Sale'
    );
        $creditCardDetails = array(
            'CREDITCARDTYPE' => 'Visa',
            'ACCT' => '4032034217357402',
            'EXPDATE' => '82019',          // Make sure this is without slashes (NOT in the format 07/2017 or 07-2017)
            'CVV2' => '984'
        );
        $payerDetails = array(
            'FIRSTNAME' => 'John',
            'LASTNAME' => 'Doe2',
            'COUNTRYCODE' => 'US',
            'STATE' => 'NY',
            'CITY' => 'New York',
            'STREET' => '14 Argyle Rd.',
            'ZIP' => '10010'
        );
        $orderParams = array(
            'AMT' => '5',               // This should be equal to ITEMAMT + SHIPPINGAMT
            'ITEMAMT' => '4',
            'SHIPPINGAMT' => '1',
            'CURRENCYCODE' => 'USD'       // USD for US Dollars
        );
        $item = array(
            'L_NAME0' => 'iPhone',
            'L_DESC0' => 'White iPhone, 16GB',
            'L_AMT0' => '4',
            'L_QTY0' => '1'
        );

       $responsedata = $this->Paypal->request('DoDirectPayment',
       $requestParams + $creditCardDetails + $payerDetails + $orderParams + $item
);
        if( is_array($responsedata) && $responsedata['ACK'] == 'Success') { // Payment successful
            // We'll fetch the transaction ID for internal bookkeeping
            $transactionId = $responsedata['TRANSACTIONID'];
        }else
        {
               Echo "There was an error processing Request!";
        }
        $this->set('responsedata',$responsedata);
       
  }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return void
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function view($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => ['ProductImages','ProductsCategories']
        ]);
        $baseurl = Configure::read('base_url');
        $this->set('baseurl',$baseurl);
        $this->set('product', $product);
        $this->set('_serialize', ['product']);
    }

    /**
     * Add method
     *
     * @return void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $product = $this->Products->newEntity();
       // debug($product->toArray());
       // die();
        if ($this->request->is('post')) {

            // pr($this->request->data);
            // die();
            $product = $this->Products->patchEntity($product, $this->request->data);
            
            //pr($product);
           // die();
            if ($this->Products->save($product)) {

                $this->Flash->success('The product has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $errors = $product->errors();
                //print_r($errors);
                $this->Flash->error('The product could not be saved. Please, try again.');
            }
        }
        $baseurl = Configure::read('base_url');
        $this->set('baseurl',$baseurl);
        $this->set('productsCategories', $this->Products->ProductsCategories->find());
        $this->set(compact('product'));
        $this->set('_serialize', ['product']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $product = $this->Products->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $product = $this->Products->patchEntity($product, $this->request->data);
            if ($this->Products->save($product)) {
                $this->Flash->success('The product has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('The product could not be saved. Please, try again.');
            }
        }
        $this->set('productsCategories', $this->Products->ProductsCategories->find('list'));
        
        $this->set(compact('product'));
        $this->set('_serialize', ['product']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return void Redirects to index.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        if ($this->Products->delete($product)) {
            $this->Flash->success('The product has been deleted.');
        } else {
            $this->Flash->error('The product could not be deleted. Please, try again.');
        }
        return $this->redirect(['action' => 'index']);
    }

    public function export() {
        $this->response->download("export.csv");
        $data = $this->Products->find('all');
        $this->set(compact('data'));
        $this->layout = 'ajax';
        exit;
    }


    public function demo()
    {
       $this->ExcelExport->createExcelDoc();

        exit;
    }

    public function excelExport()
    {
        $this->ExcelExport->createWorksheet();
        $table = [
                        array('label' => __('Sr.No'), 'width' => 10),
                        array('label' => __('Product Name'), 'width' => 30, 'filter' => true),
                        array('label' => __('Product Description'), 'width' => 30, 'filter' => true,'wrap' => true),
                        array('label' => __('Category'), 'width' => 30, 'filter' => true),
                        array('label' => __('Product Price'), 'width' => 30, 'wrap' => true,'filter' => true)
                    ];

        $products = $this->Products->find('all',['contain' => ['ProductsCategories']]);

        $this->ExcelExport->setWorksheetName('Products');
        $this->ExcelExport->addTableHeader($table, array('name' => 'Cambria', 'bold' => true));
    
        $srno = 1;
        foreach ($products as $product)
        {
            
            $row = [
                        $srno,
                        $product->product_name,
                        $product->product_description,
                        $product->products_category->category_name,
                        $product->product_price
                    ];
            
            $this->ExcelExport->addTableRow($row);

            $srno++;
        }


        $this->ExcelExport->addTableFooter();
        $this->ExcelExport->output('Product_export.xlsx');
        exit;
    }

    public function excelimport()
    {
        $errors = [];
        $product = $this->Products->newEntity(); // appllies entity validation
        if ($this->request->is('post')) 
        {
            
            $validator = $this->Products->validationImport(new Validator());

            // validate request data
            $errors = $validator->errors($this->request->data());
            
            if (empty($errors))
            {

                    // file upload
                    $filename = (isset($_FILES['filename']['name']))? $_FILES['filename']['name']: '';

                    if(!empty($filename))
                    {
                        $tmpname = $_FILES['filename']['tmp_name'];
                        
                        //Moving Uploaded File
                        if(move_uploaded_file($tmpname, $_SERVER['DOCUMENT_ROOT'] . '/vikas/bookmarksapp/webroot/uploads/import/'.$filename))
                        {       
                           
                           //$entity['filename'] = $filename; 

                            $this->ExcelExport->loadWorksheet($_SERVER['DOCUMENT_ROOT'] . '/vikas/bookmarksapp/webroot/uploads/import/'.$filename);
                            
                            $noofrec = $this->ExcelExport->getRowsCount();


                            $query = $this->Products->find('all');     
                            $number = $query->count();

                            $insert_id = ($number > 0)? ($number+1) : 1;

                            $insertedRecCount = 0;

                            for($row = 1; $row <= $noofrec; ++ $row) 
                            {
                                if($row == 1)
                                    continue;

                                $product = $this->Products->newEntity(); 

                                $rowData = $this->ExcelExport->getRowData($row);
                                
                                $file_name = ($rowData[5] != '')? $rowData[5] : 'default-product.jpg';

                                $file_arr = pathinfo($file_name);

                                $image_name = "default-product.jpg";

                                if($file_name != 'default-product.jpg')
                                 $image_name = $insert_id."_1.".$file_arr['extension'];
                               
                                   

                                $insert_id++;
                                
                                $productarr = [
                                    'product_name' => $rowData[1],
                                    'product_description' => $rowData[2],
                                    'category_id' => 1,
                                    'product_price' => $rowData[4],
                                    'product_images' => [
                                        '0' => [
                                            'image_name' => $image_name
                                        ]
                                    ]
                                    ];


                                 $product = $this->Products->patchEntity($product, $productarr);
                                     // pr($rowData);
                                     // pr($product);
                                     // die();


                                /*$product = $this->Products->newEntity([
                                    'product_name' => $rowData[1],
                                    'product_description' => $rowData[2],
                                    'category_id' => 1,
                                    'product_price' => $rowData[4]
                                    ]); */

                                $this->Products->removeBehavior('FilesUploads');
                                $this->Products->save($product);

                                if(isset($image_name) && $image_name !='default-product.jpg')
                                {
                                    fopen(WWW_ROOT.'/uploads/'.$image_name,'w+');
                                    $newfile = WWW_ROOT.'/uploads/'.$image_name;
                                    $file_to_import = WWW_ROOT.'/testing/'.$rowData[5];
                                    $current = file_get_contents($file_to_import);

                                    file_put_contents($newfile,$current);

                                }

                                $insertedRecCount++;

                            }

                          /*  echo $this->ExcelExport->getColumnsCount();

                            pr($this->ExcelExport->getRowData(2));
                            die();

                             $this->ExcelExport->readSheet($_SERVER['DOCUMENT_ROOT'] . '/vikas/bookmarksapp/webroot/uploads/import/'.$filename,$product);
                            $product = $this->Products->patchEntity($product, $this->request->data);
            
            
                            if ($this->Products->save($product))
                            {

                                $this->Flash->success('The product has been saved.');
                                return $this->redirect(['action' => 'index']);
                           }   
                            */

                           unlink($_SERVER['DOCUMENT_ROOT'] . '/vikas/bookmarksapp/webroot/uploads/import/'.$filename);   

                            $this->Flash->success($insertedRecCount.' Products Imported Successfully');
                            return $this->redirect(['action' => 'excelimport']);
                        
                        }else{ 

                            $this->Flash->success('Can not be upload');
                            return $this->redirect(['action' => 'excelimport']);
                        
                                
                        }

                    }


            }

            //pr($errors);
        }

        $this->set(compact('product','errors'));
    }


    public function cacheDemo()
    {
       // Cache::delete('products');

        $product_arr = [];
         if (($products = Cache::read('products')) === false) 
         {
            echo "Retriving Products From Database";
            $products = $this->Products->find('all');

            foreach($products as $product)
            {
                $product_arr[] = $product->id;

                
            }

            Cache::write('products', json_encode($products));
            
         }else
         {
            echo "Retriving Products From Cache";
         }

        pr(json_decode($products));
       
        exit;

    }
  
}   

