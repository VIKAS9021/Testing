Cakephp3 Excel Import Export Component
---------------------------------------
1) Install with composer (from app directory)
	composer require phpoffice/phpexcel

=> This will add above libary in vendor folder
with neccessary modification in composer.json
 "require": {
 "phpoffice/phpexcel": "dev-master"
    }
2) 
Add below line
in composer.json
"autoload": {
"phpoffice\\": "./vendor/phpoffice/phpexcel"
}

vendor/phpoffice/phpexcel : path that is upto the composer.json
of phpoffice library

3) load component in controller and there u can use components methods directly,

eg  $this->ExcelExport->createWorksheet();


//Useful Link
Excel Helper Link
  https://www.dropbox.com/s/rhebvuzl2roe9re/PhpExcelHelper.php?dl=0
  http://tutscode.com/export-to-file-excel-in-cakephp.html


  Reading Spreadsheet
  -------------------------
  http://blog.mayflower.de/561-Import-and-export-data-using-PHPExcel.html