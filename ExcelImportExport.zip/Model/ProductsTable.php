<?php
namespace App\Model\Table;

use App\Model\Entity\Product;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Event\Event;
use App\Model\Table\ArrayObject;

use Search\Manager;

//use App\Database\Expression\BetweenComparison;
//use Cake\Database\Expression\IdentifierExpression;
/**
 * Products Model
 */
class ProductsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        $this->table('products');
        $this->displayField('id');
        $this->primaryKey('id');
        $this->addBehavior('Timestamp');
        $this->addBehavior('FilesUploads');
        $this->addBehavior('Search.Search');

        $this->hasMany('ProductImages', [
            'foreignKey' => 'product_id'
        ]);
         $this->belongsTo('ProductsCategories', [
            'foreignKey' => 'category_id',
            'joinType' => 'INNER'
        ]);
    }
    /** Search plugin method **/
    public function searchConfiguration()
    {
        $search = new Manager($this);
        $search
        ->like('product_name', [
            'before' => true,
            'after' => true,
            'field' => [$this->alias() . '.product_name']
        ]);

        /*

         ->value('currency_id', [
            'field' => $this->alias() . '.currency_id'
        ])
        ->like('product_name', [
            'before' => true,
            'after' => true,
            'field' => [$this->alias() . '.product_name']
        ]);

        */
        return $search;
    }
    /** Search plugin method ends**/
    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->add('id', 'valid', ['rule' => 'numeric'])
            ->allowEmpty('id', 'create')
            ->requirePresence('product_name', 'create')
            ->notEmpty('product_name')
            ->requirePresence('product_description', 'create')
            ->notEmpty('product_description')
            ->add('product_price', 'valid', ['rule' => 'numeric'])
            ->requirePresence('product_price', 'create')
            ->notEmpty('product_price')
            ->notEmpty('category_id')
            ->requirePresence('category_id'); 

        return $validator;
    }

    public function validationImport(Validator $validator)
    {
        $validator
            ->notEmpty('filename','No File Selected')
            ->add('filename', 'custom', [
                'rule' => function ($value, $context){
                    $extension = pathinfo($value['name'])['extension'];

                    if(in_array($extension,['xlsx']))
                        return true;
                    else
                        return false;
                    // Custom logic that returns true/false
                },
                'message' => 'Invalid File Format'
            ]);

            return $validator;
    }

    /*
    ->add('filename', 'custom', [
                'rule' => function ($value, $context){
                    if($value['size'] > 50000)
                        return false;
                    else
                        return true;
                    
                    // Custom logic that returns true/false
                },
                'message' => 'File size exceed'
            ])




            ->add('filename','extension',[
                'rule' => ['extension',['xls']],
                'message' => 'Invalid File Format'
                ])
    */

    function customPaginate($page,$limit)
    {
        
     
        //$row_start = ($page-1) * $limit;
        // echo $sql = "
        //   SELECT products.* from products
        //   LIMIT 0, 3
        // ";
        //  return $this->query($sql);
       
        // way 2
        /*$conn = ConnectionManager::get('default');

        $query = $conn->newQuery();
        $query->select('products.*')
                ->from('products')
                ->limit($limit)
                ->page($page);
       
        return $query->execute(); */


        //way 2

        // $offset = ($page - 1) * $limit = $row_start
         $query = $this->find()
            ->contain(['ProductImages'])
            ->limit($limit)
            ->page($page);

        return $query; 

    }

    function customSearch($cat_id,$product_price)
    {
        $cond_arr = [];

        if($cat_id != 'all' && $cat_id !='')
        {
            $cond_arr['category_id'] = $cat_id;
        }
        
        if( !empty($product_price) )
        {

            if(count(explode('-',$product_price)) == 2)
            {
                $price_arr = explode('-',$product_price);
                $cond_arr['product_price >'] = $price_arr[0];
                $cond_arr['product_price <'] = $price_arr[1];

            }else if(count(explode('_',$product_price)) == 2)
            {
                $price_arr = explode('_',$product_price);
                $key = $price_arr[0];
                $value = $price_arr[1];

                $cond_arr["product_price $key" ] = $value;
            } 
        }

        // pr($cond_arr);
        // die();
        // $between = new BetweenComparison(
        //     new IdentifierExpression('product_price'),
        //     ['2014-01-01' => 'date'],
        //     ['2014-12-31' => 'date']
        // );

        /* return $query = $this->find()
            ->contain(['ProductImages'])
            ->where(['category_id' => $cat_id]);   */ 
        if(count($cond_arr) > 0)
        {
            
            return $query = $this->find()
            ->contain(['ProductImages'])
            ->where($cond_arr);

        }else{
             
             return $query = $this->find()
            ->contain(['ProductImages']);
        }  
                
    }


    function searchByPriceRange($min,$max)
    {
        
        $cond_arr['product_price >'] = $min;
        $cond_arr['product_price <'] = $max;

        return $query = $this->find()
            ->contain(['ProductImages'])
            ->where($cond_arr);
    }
}
