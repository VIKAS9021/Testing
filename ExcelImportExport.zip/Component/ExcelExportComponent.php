<?php
namespace App\Controller\Component;
use Cake\Controller\Component;
use Cake\Controller\ComponentRegistry;

use PHPExcel;
use PHPExcel_IOFactory;
use PHPExcel_Cell;
use PHPExcel_Cell_DataType;

class ExcelExportComponent extends Component
{
    /**
     * Instance of PHPExcel class
     *
     * @var PHPExcel
     */
    protected $objPHPExcel;
 
    /**
     * Pointer to current row
     *
     * @var int
     */
    protected $_row = 1;
 
    /**
     * Internal table params
     *
     * @var array
     */
    protected $_tableParams;

    public function createWorksheet() 
    {
        $this->objPHPExcel = new PHPExcel();

        $this->_row = 1;
 
        return $this;
    }

    public function loadWorksheet($file)
    {
        
        $this->objPHPExcel = PHPExcel_IOFactory::load($file);
        $this->_row = 1;
 
        return $this;
    }

    public function output($filename = 'export.xlsx', $writer = 'Excel2007')
    {
        // remove all output
        ob_end_clean();
 
        // headers
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment;filename=\"$filename\"");
        header('Cache-Control: max-age=0');

        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
        header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header ('Pragma: public'); // HTTP/1.0
 
        // writer
        $objWriter = $this->getWriter($writer);
        $objWriter->save('php://output');
 
        exit;
    }

    public function getWriter($writer)
    {
        return PHPExcel_IOFactory::createWriter($this->objPHPExcel, $writer);
    }
   
    public function save($file, $writer = 'Excel2007') 
    {
        $objWriter = $this->getWriter($writer);
        return $objWriter->save($file);
    }

    public function addData($data, $offset = 0) 
    {
        // solve textual representation
        if (!is_numeric($offset))
            $offset = PHPExcel_Cell::columnIndexFromString($offset);
 
        foreach ($data as $d)
            $this->objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($offset++, $this->_row, $d);
 
        $this->_row++;
 
        return $this;
    }

    public function addTableFooter() 
    {
        // auto width
        foreach ($this->_tableParams['auto_width'] as $col)
            $this->objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($col)->setAutoSize(true);
 
        // filter (has to be set for whole range)
        if (count($this->_tableParams['filter']))
            $this->objPHPExcel->getActiveSheet()->setAutoFilter(PHPExcel_Cell::stringFromColumnIndex($this->_tableParams['filter'][0]) . ($this->_tableParams['header_row']) . ':' . PHPExcel_Cell::stringFromColumnIndex($this->_tableParams['filter'][count($this->_tableParams['filter']) - 1]) . ($this->_tableParams['header_row'] + $this->_tableParams['row_count']));
 
        // wrap
        foreach ($this->_tableParams['wrap'] as $col)
            $this->objPHPExcel->getActiveSheet()->getStyle(PHPExcel_Cell::stringFromColumnIndex($col) . ($this->_tableParams['header_row'] + 1) . ':' . PHPExcel_Cell::stringFromColumnIndex($col) . ($this->_tableParams['header_row'] + $this->_tableParams['row_count']))->getAlignment()->setWrapText(true);
 
        return $this;
    }

    public function addTableRow($data)
    {
        $offset = $this->_tableParams['offset'];
 
        foreach ($data as $d)
            $this->objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($offset++, $this->_row, $d);
   
    //$this->objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($offset++, $this->_row, $d,PHPExcel_Cell_DataType::TYPE_STRING);
   
        $this->_row++;
        $this->_tableParams['row_count']++;
 
        return $this;
    }

    public function addTableHeader($data, $params = array())
    {
        // offset
        $offset = 0;
        if (isset($params['offset']))
            $offset = is_numeric($params['offset']) ? (int)$params['offset'] : PHPExcel_Cell::columnIndexFromString($params['offset']);
 
        // font name
        if (isset($params['font']))
            $this->objPHPExcel->getActiveSheet()->getStyle($this->_row)->getFont()->setName($params['font']);
 
        // font size
        if (isset($params['size']))
            $this->objPHPExcel->getActiveSheet()->getStyle($this->_row)->getFont()->setSize($params['size']);
 
        // bold
        if (isset($params['bold']))
            $this->objPHPExcel->getActiveSheet()->getStyle($this->_row)->getFont()->setBold($params['bold']);
 
        // italic
        if (isset($params['italic']))
            $this->objPHPExcel->getActiveSheet()->getStyle($this->_row)->getFont()->setItalic($params['italic']);
 
        // set internal params that need to be processed after data are inserted
        $this->_tableParams = array(
            'header_row' => $this->_row,
            'offset' => $offset,
            'row_count' => 0,
            'auto_width' => array(),
            'filter' => array(),
            'wrap' => array()
        );
 
        foreach ($data as $d) {
            // set label
            $this->objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($offset, $this->_row, $d['label']);
 
            // set width
            if (isset($d['width']) && is_numeric($d['width']))
                $this->objPHPExcel->getActiveSheet()->getColumnDimensionByColumn($offset)->setWidth((float)$d['width']);
            else
                $this->_tableParams['auto_width'][] = $offset;
 
            // filter
            if (isset($d['filter']) && $d['filter'])
                $this->_tableParams['filter'][] = $offset;
 
            // wrap
            if (isset($d['wrap']) && $d['wrap'])
                $this->_tableParams['wrap'][] = $offset;
 
            $offset++;
        }
        $this->_row++;
 
        return $this;
    } 

    public function setRow($row) {
        $this->_row = (int)$row;
        return $this;
    }

    public function setDefaultFont($name, $size) {
        $this->objPHPExcel->getDefaultStyle()->getFont()->setName($name);
        $this->objPHPExcel->getDefaultStyle()->getFont()->setSize($size);
 
        return $this;
    }

    public function setWorksheetName($name) {
        $this->objPHPExcel->getActiveSheet()->setTitle($name);
 
        return $this;
    }

    public function __call($name, $arguments) {
        return call_user_func_array(array($this->objPHPExcel, $name), $arguments);
    }
 
   public function getRowData($row)
   {
        $rowdata = [];
        $highestColumnIndex = $this->getColumnsCount();

        for ($col = 0; $col < $highestColumnIndex; ++ $col) 
        {
            $cell = $this->objPHPExcel->getActiveSheet()->getCellByColumnAndRow($col, $row);
            $val = $cell->getValue();

            $rowdata[] = $val;
        }

        return $rowdata;
   }

   public function getRowsCount()
   {
        $highestRow = $this->objPHPExcel->getActiveSheet()->getHighestRow(); // e.g. 10  

        return $highestRow;  
   }

   public function getColumnsCount()
   {
       $highestDataColumm = $this->objPHPExcel->getActiveSheet()->getHighestDataColumn(); // e.g. 10  

       $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestDataColumm);
        
       return $highestColumnIndex;      
   }

   public function readSheet($file,$entity)
   {
        $entity->product_name = 'PQR';
        // $entity->set('product_name','Abcd');
        // $entity->set('product_name','Abcd');
        // $entity->set('product_name','Abcd');
        // $entity->set('product_name','Abcd');

        pr($entity);
        $objPHPExcel = PHPExcel_IOFactory::load($file);

        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) 
        {
            $worksheetTitle     = $worksheet->getTitle();
            
            // total rows
            $highestRow         = $worksheet->getHighestRow(); // e.g. 10
            
            // total columns
            $highestColumn      = $worksheet->getHighestColumn(); // e.g 'AMK'
            
            $highestDataColumm = $worksheet->getHighestDataColumn(); // e.g 'F'

            echo $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestDataColumm);
            // echo PHPExcel_Cell::columnIndexFromString('A');
            // echo "<br />";
            // echo PHPExcel_Cell::columnIndexFromString('B');
            // echo "<br />";
            // echo PHPExcel_Cell::columnIndexFromString('C');
            // echo "<br />";
            $nrColumns = ord($highestDataColumm) - 64;
            echo "<br>The worksheet ".$worksheetTitle." has ";
            echo $nrColumns . ' columns (A-' . $highestColumn . ') ';
            echo ' and ' . $highestRow . ' row.<BR><BR>';


            echo '<br>Data: <table border="1"><tr>';
            for ($row = 1; $row <= $highestRow; ++ $row) {
                echo '<tr>';
                for ($col = 0; $col < $highestColumnIndex; ++ $col) {

                    $cell = $worksheet->getCellByColumnAndRow($col, $row);
                    $val = $cell->getValue();
                   // $dataType = PHPExcel_Cell_DataType::dataTypeForValue($val);
                    echo '<td>' . $val . '</td>';
                }
                echo '</tr>';
            }
            echo '</table>';

           die();
        }
   }
 
    public function createExcelDoc()
    {

        error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
    die('This example should only be run from a Web Browser');

        $objPHPExcel = new PHPExcel();


// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
                             ->setLastModifiedBy("Maarten Balliauw")
                             ->setTitle("Office 2007 XLSX Test Document")
                             ->setSubject("Office 2007 XLSX Test Document")
                             ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
                             ->setKeywords("office 2007 openxml php")
                             ->setCategory("Test result file");


// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Hello')
            ->setCellValue('B2', 'world!')
            ->setCellValue('C1', 'Hello')
            ->setCellValue('D2', 'world!');

// Miscellaneous glyphs, UTF-8
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A4', 'Miscellaneous glyphs')
            ->setCellValue('A5', 'éàèùâêîôûëïüÿäöüç');

// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Simple');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);

ob_end_clean();
// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="01simple.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

//pr($objWriter);
//die();
$objWriter->save('php://output');
exit;

    }
}